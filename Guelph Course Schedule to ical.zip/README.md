University of Guelph Website Enhancer
======================================

Export the University of Guelph's course schedule to various formats (ICAL being the main one)
