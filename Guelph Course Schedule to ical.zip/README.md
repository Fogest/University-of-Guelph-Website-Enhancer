University-of-Guelph-Schedule-Exporter
======================================

Export the University of Guelph's course schedule to various formats (ICAL being the main one)
